import { Component, OnInit ,ViewChild,Input} from '@angular/core';
import * as $ from "jquery";
import { Router ,Event, } from '@angular/router';
import { MatSidenav } from '@angular/material/sidenav';
import * as data from './../../../assets/data/Menu.json';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
	@ViewChild('sidenav') sidenav: MatSidenav;
	menuList: any = ((data as any).default).menu;
	isExpanded = true;
	isShowing = false;
	showSubSubMenu: boolean = false;
	@Input() varient = false;
	@Input() isOver = false;
	isToggle:boolean=false;
	activeMenu:number=0;
	constructor(private router: Router ) {
		setTimeout(() => {
			$('.sidebar-inner').css('height',window.innerHeight);
		}, 500);
	}

	ngOnInit() {
		console.log(this.menuList, 'menuList');
	}

	setStep(i){

	}

}