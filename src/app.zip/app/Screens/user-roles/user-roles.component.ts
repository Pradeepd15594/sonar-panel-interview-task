import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../AppServices/auth.service';
@Component({
  selector: 'app-user-roles',
  templateUrl: './user-roles.component.html',
  styleUrls: ['./user-roles.component.scss']
})
export class UserRolesComponent implements OnInit {
  manageUsers:any={view:true, add:true,edit:true};
  userRoles:any={view:false, add:false,edit:false};
  rolesList:any=[];
  constructor(private authService:AuthService) {
    this.authService.shairedData.subscribe(res => {
      if(res!=null && res!='' && res!=undefined){
        this.rolesList=JSON.parse(localStorage.getItem('@userRoles'));
      }
    })
  }

  ngOnInit(): void {
   
  }


  /*submitRole*/
  submitRole(){
    let temp:any={
      manageUsers:this.manageUsers,
      userRoles:this.userRoles,
    };
    localStorage.setItem('@userRoles', JSON.stringify(temp));
  }

}
