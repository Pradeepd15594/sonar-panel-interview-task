import { Injectable, NgZone } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot,ActivatedRoute, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import{AuthService} from './AppServices/auth.service';
import { Routes, RouterModule } from '@angular/router';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard implements CanActivate {
  
    Roles:any=[];
    userAuth:any=[];
    parmsId:any=null;
    constructor(
        private authService: AuthService, 
        private router: Router,
        private _route: ActivatedRoute) {
        this.setAuth();
    }

    ngOnInit() {
        let id = this._route.snapshot.params.id;
        console.log(id);
    }


    setAuth():any{
        try {
            let auth=localStorage.getItem('@userSession');
            if(auth!="" && auth!=undefined && auth !=null){
                
               
                
                this.userAuth=JSON.parse((auth));
                this.Roles=JSON.parse(localStorage.getItem('@userRoles'));
                console.log(auth, this.Roles);
            }
        } catch (error) {
            this.router.navigateByUrl("/login");
        }
    }


    public canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot):Observable<boolean>|boolean {
        this.setAuth();
        console.log(this.Roles, 'this.Roles');
        switch (route.routeConfig.path) {
            
            
            case 'user-lists':
                if(this.Roles?.orderModule?.add!=true && this.Roles?.orderModule?.add!=undefined){ 
                  this.router.navigateByUrl("/404");
                  return false;
                }

            break;
        }
        
    }
  
}